import java.awt.BorderLayout;
import java.awt.EventQueue;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.Color;

public class Unit2 extends JFrame {

	private JPanel contentPane;
	private DBNW database;
	private String server;
	private String Database;
	private String user;
	private String password;
	private Boolean isValid = true;
	
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Unit2 frame = new Unit2();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	
	public Unit2() {
		setTitle("User Access");
		setBackground(new Color(255, 245, 238));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 500, 700);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(189, 183, 107));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblConnect = new JLabel("Connect");
		lblConnect.setBounds(15, 25, 100, 20);
		contentPane.add(lblConnect);

		JButton btnConnect = new JButton("Connect to Northwind DB");
		btnConnect.setBackground(new Color(255, 250, 205));
		btnConnect.setBounds(150, 20, 200, 30);
		btnConnect.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					String dbURL = "jdbc:sqlserver://LAPTOP-HK7J2UI2\\SQLEXPRESS;"
			                + "database=Northwind;"
			                + "user=sa;"
			                + "password=123456;"
			                + "encrypt=false;"
			                + "loginTimeout=10;";		
					database = new DBNW(dbURL);
					JOptionPane.showMessageDialog(null, "Connected");
				}catch(Exception e) {
					JOptionPane.showMessageDialog(null, e.getMessage());
				}
				
				}
			});

		
		contentPane.add(btnConnect);
		
		JLabel lblCount = new JLabel("Customer Count");
		lblCount.setBounds(15, 75, 100, 20);
		contentPane.add(lblCount);
		
		JButton btnCount = new JButton("Customer Count");
		btnCount.setBackground(new Color(255, 250, 205));
		btnCount.setBounds(150, 70, 200, 30);
		btnCount.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					String countValue = database.getCustomerCount();
					JOptionPane.showMessageDialog(null, "The customer count is: " + countValue);
				}catch(Exception e) {
					JOptionPane.showMessageDialog(null, e.getMessage());
				}
				
			}
		});
		contentPane.add(btnCount);
		
		JLabel lblName = new JLabel("Names");
		lblName.setBounds(15, 125, 100, 20);
		contentPane.add(lblName);
		
		JButton btnName = new JButton("Customer Names");
		btnName.setBackground(new Color(255, 250, 205));
		btnName.setBounds(150, 120, 200, 30);
		btnName.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					String nameValue = database.getContactNames();
					javax.swing.JOptionPane.showMessageDialog(null, "Our Customer names are: \n" + nameValue);
				}catch(Exception e) {
					JOptionPane.showMessageDialog(null, e.getMessage());
				}
				
			}
		});
		contentPane.add(btnName);		
		
		
		
		JLabel lblServer = new JLabel("Server");
		lblServer.setBounds(15, 186, 100, 20);
		contentPane.add(lblServer);	
		
		JTextField tfServer = new JTextField("LAPTOP-HK7J2UI2");
		tfServer.setBounds(150, 181, 200, 30);
		contentPane.add(tfServer);
		
		JLabel lblDatabase = new JLabel("Database");
		lblDatabase.setBounds(15, 255, 100, 20);
		contentPane.add(lblDatabase);	
		
		JTextField tfDatabase = new JTextField("Northwind");
		tfDatabase.setBounds(150, 250, 200, 30);
		contentPane.add(tfDatabase);
				
		JLabel lblUser = new JLabel("User");
		lblUser.setBounds(15, 324, 49, 20);
		contentPane.add(lblUser);	
		
		JTextField tfUser = new JTextField(20);
		tfUser.setBounds(150, 319, 200, 30);
		contentPane.add(tfUser);
		
		JLabel lblPassword = new JLabel("Password");
		lblPassword.setBounds(15, 390, 100, 20);
		contentPane.add(lblPassword);	
		
		final JPasswordField pfPassword = new JPasswordField(20);
		pfPassword.setBounds(150, 385, 200, 30);
		contentPane.add(pfPassword);
			
	
	JButton btnlogin = new JButton("login");
	btnlogin.setBackground(new Color(255, 240, 245));
	btnlogin.setBounds(150, 492, 200, 30);
	btnlogin.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent arg0) {
			try {
				isValid = true;
			    String server = tfServer.getText();
			    String Database = tfDatabase.getText();
			    String user = tfUser.getText();
			    String password = pfPassword.getText();
			    			
					if(isValid) {
					String dbURL = "jdbc:sqlserver://" + server + "\\SQLEXPRESS;"
							+ "database=" + Database + ";"
							+ "user=" + user + ";"
							+ "password=" + password + ";"
							+ "encrypt=false;"
							+ "trustServerCertificate=false;"
							+ "loginTimeout=10;";			
					database = new DBNW(dbURL);
					JOptionPane.showMessageDialog(null, "Connected");
					}
				else {
					JOptionPane.showMessageDialog(null, "Invalid login parameters: " + server + ", " + Database + ", " + user + ", " + password);	
					}
				}catch(Exception e) {
					JOptionPane.showMessageDialog(null, e.getMessage());
				}
				
				}
			});  
	contentPane.add(btnlogin);
			}
}
